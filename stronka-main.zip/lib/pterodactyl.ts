import {
  mockServers,
  mockUsers,
  mockNodes,
  mockEggs,
  mockLocations,
  mockActivity,
  mockBackups,
  mockFiles,
  generateCpuData,
  generateRamData,
  generateDiskData,
  generateServerActivityData,
} from './mock-data';
import type {
  PteroServer,
  PteroUser,
  PteroNode,
  PteroEgg,
  PteroLocation,
  ActivityLog,
  Backup,
  FileEntry,
  ServerStatus,
} from './types';

/**
 * Klient API Pterodactyl.
 * W trybie demonstracyjnym zwraca dane mockowe.
 * Gdy skonfigurowano PTERODACTYL_URL i PTERODACTYL_API_KEY,
 * funkcje mogą zostać rozszerzone o realne wywołania Application API.
 */

const PTERO_URL = process.env.PTERODACTYL_URL || '';
const PTERO_KEY = process.env.PTERODACTYL_API_KEY || '';

export const isPteroConfigured = () => Boolean(PTERO_URL && PTERO_KEY);

async function pteroFetch<T>(path: string): Promise<T> {
  const res = await fetch(`${PTERO_URL}/api/application${path}`, {
    headers: {
      Authorization: `Bearer ${PTERO_KEY}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    cache: 'no-store',
  });
  if (!res.ok) throw new Error(`Pterodactyl API: ${res.status}`);
  return res.json();
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function getServers(): Promise<PteroServer[]> {
  await delay(300);
  if (isPteroConfigured()) {
    try {
      const data = await pteroFetch<{ data: any[] }>('/servers');
      return data.data.map((item) => mapPteroServer(item.attributes));
    } catch {
      return mockServers;
    }
  }
  return mockServers;
}

function mapPteroServer(a: any): PteroServer {
  return {
    id: String(a.id),
    identifier: a.identifier,
    name: a.name,
    owner: a.user || '',
    ownerId: String(a.owner),
    node: a.node || '',
    nodeId: String(a.node_id),
    status: (a.status as ServerStatus) || 'stopped',
    ram: 0,
    ramLimit: a.limits?.memory || 0,
    cpu: 0,
    cpuLimit: a.limits?.cpu || 0,
    disk: 0,
    diskLimit: a.limits?.disk || 0,
    port: a.allocation?.port || 0,
    createdAt: a.created_at?.split('T')[0] || '',
    egg: a.egg || '',
    eggId: String(a.egg_id || ''),
    databases: a.feature_limits?.databases || 0,
    backups: a.feature_limits?.backups || 0,
    ports: a.feature_limits?.allocations || 0,
  };
}

export async function getServer(id: string): Promise<PteroServer | null> {
  await delay(200);
  return mockServers.find((s) => s.id === id || s.identifier === id) || null;
}

export async function powerAction(
  identifier: string,
  action: 'start' | 'stop' | 'restart' | 'kill'
): Promise<{ success: boolean }> {
  await delay(400);
  if (isPteroConfigured()) {
    try {
      await fetch(`${PTERO_URL}/api/client/servers/${identifier}/power`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${PTERO_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ signal: action }),
      });
    } catch {
      // try application endpoint fallback
    }
  }
  return { success: true };
}

export async function getUsers(): Promise<PteroUser[]> {
  await delay(250);
  return mockUsers;
}

export async function getNodes(): Promise<PteroNode[]> {
  await delay(250);
  return mockNodes;
}

export async function getEggs(): Promise<PteroEgg[]> {
  await delay(150);
  return mockEggs;
}

export async function getLocations(): Promise<PteroLocation[]> {
  await delay(150);
  return mockLocations;
}

export async function getActivity(): Promise<ActivityLog[]> {
  await delay(200);
  return mockActivity;
}

export async function getBackups(serverId: string): Promise<Backup[]> {
  await delay(200);
  return mockBackups;
}

export async function getFiles(serverId: string, path = '/'): Promise<FileEntry[]> {
  await delay(200);
  return mockFiles;
}

export async function createServer(input: {
  name: string;
  userId: string;
  eggId: string;
  nodeId: string;
  ram: number;
  cpu: number;
  disk: number;
  databases: number;
  backups: number;
  ports: number;
}): Promise<{ success: boolean; id?: string; error?: string }> {
  await delay(500);
  if (!input.name || input.name.length < 3) {
    return { success: false, error: 'Nazwa serwera musi mieć co najmniej 3 znaki.' };
  }
  if (input.ram < 512) {
    return { success: false, error: 'RAM musi wynosić co najmniej 512 MB.' };
  }
  if (input.cpu < 50) {
    return { success: false, error: 'CPU musi wynosić co najmniej 50%.' };
  }
  if (input.disk < 1024) {
    return { success: false, error: 'Dysk musi wynosić co najmniej 1024 MB.' };
  }
  return { success: true, id: `srv-${Math.floor(Math.random() * 1000)}` };
}

export async function createUser(input: {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  password: string;
}): Promise<{ success: boolean; error?: string }> {
  await delay(400);
  if (!input.email.includes('@')) return { success: false, error: 'Nieprawidłowy adres e-mail.' };
  if (input.password.length < 8) return { success: false, error: 'Hasło musi mieć co najmniej 8 znaków.' };
  return { success: true };
}

export async function createNode(input: {
  name: string;
  locationId: string;
  fqdn: string;
  ram: number;
  disk: number;
}): Promise<{ success: boolean; error?: string }> {
  await delay(400);
  if (!input.name) return { success: false, error: 'Nazwa node jest wymagana.' };
  if (!input.fqdn) return { success: false, error: 'Adres FQDN jest wymagany.' };
  return { success: true };
}

export {
  generateCpuData,
  generateRamData,
  generateDiskData,
  generateServerActivityData,
};
