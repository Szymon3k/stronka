import type {
  PteroServer,
  PteroUser,
  PteroNode,
  PteroEgg,
  PteroLocation,
  ActivityLog,
  Backup,
  FileEntry,
} from './types';

export const mockServers: PteroServer[] = [
  {
    id: 'srv-001', identifier: 'a1b2c3', name: 'Survival World', owner: 'Jan Kowalski', ownerId: 'usr-001',
    node: 'Warszawa-01', nodeId: 'node-01', status: 'running', ram: 2048, ramLimit: 4096,
    cpu: 42, cpuLimit: 200, disk: 5120, diskLimit: 10240, port: 25565, createdAt: '2025-03-12',
    egg: 'Paper MC', eggId: 'egg-01', databases: 1, backups: 3, ports: 1,
  },
  {
    id: 'srv-002', identifier: 'd4e5f6', name: 'Creative Build', owner: 'Anna Nowak', ownerId: 'usr-002',
    node: 'Warszawa-01', nodeId: 'node-01', status: 'running', ram: 1024, ramLimit: 2048,
    cpu: 18, cpuLimit: 100, disk: 2048, diskLimit: 5120, port: 25566, createdAt: '2025-04-01',
    egg: 'Vanilla MC', eggId: 'egg-02', databases: 0, backups: 1, ports: 1,
  },
  {
    id: 'srv-003', identifier: 'g7h8i9', name: 'SkyBlock Pro', owner: 'Piotr Wiśniewski', ownerId: 'usr-003',
    node: 'Frankfurt-02', nodeId: 'node-02', status: 'stopped', ram: 0, ramLimit: 8192,
    cpu: 0, cpuLimit: 400, disk: 8192, diskLimit: 20480, port: 25567, createdAt: '2025-02-18',
    egg: 'Paper MC', eggId: 'egg-01', databases: 2, backups: 5, ports: 2,
  },
  {
    id: 'srv-004', identifier: 'j0k1l2', name: 'Discord Bot', owner: 'Katarzyna Lewandowska', ownerId: 'usr-004',
    node: 'Frankfurt-02', nodeId: 'node-02', status: 'running', ram: 512, ramLimit: 1024,
    cpu: 8, cpuLimit: 50, disk: 512, diskLimit: 2048, port: 3000, createdAt: '2025-05-20',
    egg: 'Node.js', eggId: 'egg-03', databases: 1, backups: 0, ports: 1,
  },
  {
    id: 'srv-005', identifier: 'm3n4o5', name: 'Rust Server', owner: 'Tomasz Kamiński', ownerId: 'usr-005',
    node: 'Warszawa-01', nodeId: 'node-01', status: 'crashed', ram: 0, ramLimit: 16384,
    cpu: 0, cpuLimit: 600, disk: 16384, diskLimit: 40960, port: 28015, createdAt: '2025-01-30',
    egg: 'Rust', eggId: 'egg-04', databases: 1, backups: 2, ports: 3,
  },
  {
    id: 'srv-006', identifier: 'p6q7r8', name: 'Test Environment', owner: 'Jan Kowalski', ownerId: 'usr-001',
    node: 'Frankfurt-02', nodeId: 'node-02', status: 'suspended', ram: 0, ramLimit: 2048,
    cpu: 0, cpuLimit: 100, disk: 1024, diskLimit: 5120, port: 25568, createdAt: '2025-06-10',
    egg: 'Paper MC', eggId: 'egg-01', databases: 0, backups: 0, ports: 1,
  },
];

export const mockUsers: PteroUser[] = [
  { id: 'usr-001', username: 'jkowalski', email: 'jan.kowalski@example.com', firstName: 'Jan', lastName: 'Kowalski', role: 'admin', serversCount: 2, createdAt: '2025-01-15', status: 'active' },
  { id: 'usr-002', username: 'anowak', email: 'anna.nowak@example.com', firstName: 'Anna', lastName: 'Nowak', role: 'user', serversCount: 1, createdAt: '2025-02-20', status: 'active' },
  { id: 'usr-003', username: 'pwisniewski', email: 'piotr.w@example.com', firstName: 'Piotr', lastName: 'Wiśniewski', role: 'user', serversCount: 1, createdAt: '2025-02-05', status: 'active' },
  { id: 'usr-004', username: 'klewandowska', email: 'kasia.l@example.com', firstName: 'Katarzyna', lastName: 'Lewandowska', role: 'moderator', serversCount: 1, createdAt: '2025-03-18', status: 'active' },
  { id: 'usr-005', username: 'tkaminski', email: 'tomasz.k@example.com', firstName: 'Tomasz', lastName: 'Kamiński', role: 'user', serversCount: 1, createdAt: '2025-01-10', status: 'suspended' },
  { id: 'usr-006', username: 'mzielinska', email: 'magda.z@example.com', firstName: 'Magdalena', lastName: 'Zielińska', role: 'user', serversCount: 0, createdAt: '2025-06-01', status: 'active' },
];

export const mockNodes: PteroNode[] = [
  { id: 'node-01', name: 'Warszawa-01', location: 'Warszawa', status: 'online', cpuUsed: 60, cpuTotal: 800, ramUsed: 3584, ramTotal: 16384, diskUsed: 7168, diskTotal: 51200, servers: 3, allocations: 100, allocationsUsed: 42 },
  { id: 'node-02', name: 'Frankfurt-02', location: 'Frankfurt', status: 'online', cpuUsed: 26, cpuTotal: 1000, ramUsed: 1536, ramTotal: 32768, diskUsed: 25600, diskTotal: 102400, servers: 3, allocations: 200, allocationsUsed: 88 },
];

export const mockEggs: PteroEgg[] = [
  { id: 'egg-01', name: 'Paper MC', description: 'Wydajny serwer Minecraft z optymalizacją Paper.', dockerImage: 'ghcr.io/parkervcp/yolks:java_17', startup: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar' },
  { id: 'egg-02', name: 'Vanilla MC', description: 'Czysty serwer Minecraft bez modyfikacji.', dockerImage: 'ghcr.io/parkervcp/yolks:java_17', startup: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar' },
  { id: 'egg-03', name: 'Node.js', description: 'Środowisko Node.js dla aplikacji i botów.', dockerImage: 'ghcr.io/parkervcp/yolks:nodejs_18', startup: 'npm install && node index.js' },
  { id: 'egg-04', name: 'Rust', description: 'Serwer gry Rust z pełnym wsparciem.', dockerImage: 'ghcr.io/parkervcp/games:rust', startup: './RustDedicated -batchmode +server.port {{SERVER_PORT}}' },
];

export const mockLocations: PteroLocation[] = [
  { id: 'loc-01', name: 'Warszawa', short: 'WAW' },
  { id: 'loc-02', name: 'Frankfurt', short: 'FRA' },
];

export const mockActivity: ActivityLog[] = [
  { id: 'act-001', user: 'Jan Kowalski', action: 'uruchomił serwer', target: 'Survival World', timestamp: '2025-07-30 14:32', type: 'server' },
  { id: 'act-002', user: 'Anna Nowak', action: 'utworzyła backup', target: 'Creative Build', timestamp: '2025-07-30 13:15', type: 'server' },
  { id: 'act-003', user: 'System', action: 'wykryto awarię', target: 'Rust Server', timestamp: '2025-07-30 12:48', type: 'system' },
  { id: 'act-004', user: 'Katarzyna Lewandowska', action: 'zalogowała się', target: 'Panel', timestamp: '2025-07-30 11:02', type: 'security' },
  { id: 'act-005', user: 'Piotr Wiśniewski', action: 'zmienił ustawienia', target: 'SkyBlock Pro', timestamp: '2025-07-30 10:30', type: 'server' },
  { id: 'act-006', user: 'Jan Kowalski', action: 'dodał użytkownika', target: 'Magdalena Zielińska', timestamp: '2025-07-29 18:20', type: 'user' },
  { id: 'act-007', user: 'System', action: 'zakończył backup', target: 'Survival World', timestamp: '2025-07-29 16:00', type: 'system' },
];

export const mockBackups: Backup[] = [
  { id: 'bkp-001', name: 'Backup automatyczny', size: 512, status: 'completed', createdAt: '2025-07-30 03:00' },
  { id: 'bkp-002', name: 'Przed aktualizacją', size: 488, status: 'completed', createdAt: '2025-07-28 14:20' },
  { id: 'bkp-003', name: 'Backup ręczny', size: 502, status: 'completed', createdAt: '2025-07-25 19:45' },
];

export const mockFiles: FileEntry[] = [
  { name: 'plugins', type: 'folder', size: 0, modified: '2025-07-30 14:00', editable: false },
  { name: 'world', type: 'folder', size: 0, modified: '2025-07-30 14:32', editable: false },
  { name: 'logs', type: 'folder', size: 0, modified: '2025-07-30 14:32', editable: false },
  { name: 'server.properties', type: 'file', size: 1024, modified: '2025-07-29 20:15', editable: true },
  { name: 'paper.yml', type: 'file', size: 4096, modified: '2025-07-28 12:00', editable: true },
  { name: 'eula.txt', type: 'file', size: 128, modified: '2025-03-12 09:00', editable: true },
  { name: 'server.jar', type: 'file', size: 52428800, modified: '2025-03-12 09:00', editable: false },
];

export function generateCpuData(points = 24) {
  return Array.from({ length: points }, (_, i) => ({
    time: `${String(i).padStart(2, '0')}:00`,
    cpu: Math.round(30 + Math.sin(i / 3) * 20 + Math.random() * 15),
    limit: 100,
  }));
}

export function generateRamData(points = 24) {
  return Array.from({ length: points }, (_, i) => ({
    time: `${String(i).padStart(2, '0')}:00`,
    ram: Math.round(40 + Math.cos(i / 4) * 25 + Math.random() * 10),
    limit: 100,
  }));
}

export function generateDiskData(points = 24) {
  return Array.from({ length: points }, (_, i) => ({
    time: `${String(i).padStart(2, '0')}:00`,
    disk: Math.round(55 + Math.sin(i / 6) * 8 + Math.random() * 5),
    limit: 100,
  }));
}

export function generateServerActivityData(points = 12) {
  return Array.from({ length: points }, (_, i) => ({
    day: `${i + 1}.07`,
    aktywnosc: Math.round(20 + Math.random() * 80),
  }));
}
