export type ServerStatus = 'running' | 'starting' | 'stopping' | 'stopped' | 'crashed' | 'installing' | 'suspended';

export interface PteroServer {
  id: string;
  identifier: string;
  name: string;
  owner: string;
  ownerId: string;
  node: string;
  nodeId: string;
  status: ServerStatus;
  ram: number; // MB
  ramLimit: number; // MB
  cpu: number; // %
  cpuLimit: number; // %
  disk: number; // MB
  diskLimit: number; // MB
  port: number;
  createdAt: string;
  egg: string;
  eggId: string;
  databases: number;
  backups: number;
  ports: number;
}

export interface PteroUser {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'user' | 'moderator';
  serversCount: number;
  createdAt: string;
  status: 'active' | 'suspended' | 'banned';
}

export interface PteroNode {
  id: string;
  name: string;
  location: string;
  status: 'online' | 'offline' | 'maintenance';
  cpuUsed: number;
  cpuTotal: number;
  ramUsed: number;
  ramTotal: number;
  diskUsed: number;
  diskTotal: number;
  servers: number;
  allocations: number;
  allocationsUsed: number;
}

export interface PteroEgg {
  id: string;
  name: string;
  description: string;
  dockerImage: string;
  startup: string;
}

export interface PteroLocation {
  id: string;
  name: string;
  short: string;
}

export interface ActivityLog {
  id: string;
  user: string;
  action: string;
  target: string;
  timestamp: string;
  type: 'server' | 'user' | 'node' | 'system' | 'security';
}

export interface Backup {
  id: string;
  name: string;
  size: number;
  status: 'completed' | 'in-progress' | 'failed';
  createdAt: string;
}

export interface FileEntry {
  name: string;
  type: 'file' | 'folder';
  size: number;
  modified: string;
  editable: boolean;
}

export interface ConsoleLine {
  id: string;
  text: string;
  type: 'log' | 'command' | 'error' | 'success' | 'warn';
  timestamp: string;
}
