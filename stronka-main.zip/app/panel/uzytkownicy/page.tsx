'use client';

import { useEffect, useMemo, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Search, UserPlus, Users, Pencil, Trash2, Server, Shield, Loader2, Mail, Ban, CheckCircle2 } from 'lucide-react';
import { getUsers } from '@/lib/pterodactyl';
import type { PteroUser } from '@/lib/types';
import { cn } from '@/lib/utils';

const roleMap: Record<PteroUser['role'], { label: string; class: string }> = {
  admin: { label: 'Administrator', class: 'bg-primary/15 text-primary border-primary/30' },
  moderator: { label: 'Moderator', class: 'bg-info/15 text-info border-info/30' },
  user: { label: 'Użytkownik', class: 'bg-muted text-muted-foreground border-border' },
};

const statusMap: Record<PteroUser['status'], { label: string; class: string }> = {
  active: { label: 'Aktywny', class: 'bg-success/15 text-success border-success/30' },
  suspended: { label: 'Zawieszony', class: 'bg-warning/15 text-warning border-warning/30' },
  banned: { label: 'Zbanowany', class: 'bg-destructive/15 text-destructive border-destructive/30' },
};

export default function UsersPage() {
  const [users, setUsers] = useState<PteroUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<PteroUser | null>(null);
  const [form, setForm] = useState({ username: '', email: '', firstName: '', lastName: '', password: '' });

  useEffect(() => {
    getUsers().then((u) => {
      setUsers(u);
      setLoading(false);
    });
  }, []);

  const filtered = useMemo(
    () =>
      users.filter(
        (u) =>
          u.username.toLowerCase().includes(search.toLowerCase()) ||
          u.email.toLowerCase().includes(search.toLowerCase()) ||
          `${u.firstName} ${u.lastName}`.toLowerCase().includes(search.toLowerCase())
      ),
    [users, search]
  );

  function openCreate() {
    setEditing(null);
    setForm({ username: '', email: '', firstName: '', lastName: '', password: '' });
    setDialogOpen(true);
  }

  function openEdit(u: PteroUser) {
    setEditing(u);
    setForm({ username: u.username, email: u.email, firstName: u.firstName, lastName: u.lastName, password: '' });
    setDialogOpen(true);
  }

  function save() {
    if (!form.username || !form.email.includes('@')) {
      toast.error('Wypełnij poprawnie nazwę użytkownika i e-mail.');
      return;
    }
    if (!editing && form.password.length < 8) {
      toast.error('Hasło musi mieć co najmniej 8 znaków.');
      return;
    }
    toast.success(editing ? 'Użytkownik zaktualizowany.' : 'Użytkownik utworzony.');
    setDialogOpen(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Użytkownicy</h1>
          <p className="text-sm text-muted-foreground mt-1">Zarządzanie kontami użytkowników</p>
        </div>
        <Button onClick={openCreate} className="gradient-primary text-white">
          <UserPlus className="mr-2 h-4 w-4" /> Dodaj użytkownika
        </Button>
      </div>

      <Card className="glass p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Szukaj użytkowników..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-background/50"
          />
        </div>
      </Card>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <Card className="glass p-0 overflow-hidden">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/5 text-muted-foreground">
                  <th className="text-left p-4 font-medium">Użytkownik</th>
                  <th className="text-left p-4 font-medium">E-mail</th>
                  <th className="text-left p-4 font-medium">Rola</th>
                  <th className="text-left p-4 font-medium">Serwery</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Utworzono</th>
                  <th className="text-right p-4 font-medium">Akcje</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((u) => (
                  <tr key={u.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full gradient-primary flex items-center justify-center text-white font-semibold text-xs shrink-0">
                          {u.firstName[0]}{u.lastName[0]}
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium truncate">{u.firstName} {u.lastName}</p>
                          <p className="text-xs text-muted-foreground truncate">@{u.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-muted-foreground">{u.email}</td>
                    <td className="p-4">
                      <Badge variant="outline" className={roleMap[u.role].class}>
                        {u.role === 'admin' && <Shield className="h-3 w-3 mr-1" />}
                        {roleMap[u.role].label}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <span className="flex items-center gap-1.5">
                        <Server className="h-3.5 w-3.5 text-muted-foreground" />
                        {u.serversCount}
                      </span>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className={statusMap[u.status].class}>
                        {u.status === 'active' && <CheckCircle2 className="h-3 w-3 mr-1" />}
                        {u.status === 'suspended' && <Ban className="h-3 w-3 mr-1" />}
                        {statusMap[u.status].label}
                      </Badge>
                    </td>
                    <td className="p-4 text-muted-foreground">{u.createdAt}</td>
                    <td className="p-4">
                      <div className="flex justify-end gap-1">
                        <Button size="icon" variant="ghost" onClick={() => openEdit(u)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="text-destructive" onClick={() => toast.error('Użytkownik usunięty.')}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="glass-strong">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edytuj użytkownika' : 'Nowy użytkownik'}</DialogTitle>
            <DialogDescription>
              {editing ? 'Zaktualizuj dane użytkownika. Pozostaw hasło puste, aby nie zmieniać.' : 'Utwórz nowe konto użytkownika.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Imię</Label>
                <Input value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} className="bg-background/50" />
              </div>
              <div className="space-y-2">
                <Label>Nazwisko</Label>
                <Input value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} className="bg-background/50" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Nazwa użytkownika</Label>
              <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} className="bg-background/50" />
            </div>
            <div className="space-y-2">
              <Label>E-mail</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="bg-background/50" />
            </div>
            <div className="space-y-2">
              <Label>Hasło {editing && '(opcjonalnie)'}</Label>
              <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="bg-background/50" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Anuluj</Button>
            <Button onClick={save} className="gradient-primary text-white">{editing ? 'Zapisz' : 'Utwórz'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
