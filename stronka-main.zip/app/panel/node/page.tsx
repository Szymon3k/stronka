'use client';

import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Network, Plus, Cpu, MemoryStick, HardDrive, Server, MapPin, Loader2, Pencil } from 'lucide-react';
import { getNodes, getLocations } from '@/lib/pterodactyl';
import type { PteroNode, PteroLocation } from '@/lib/types';
import { cn } from '@/lib/utils';

const statusMap: Record<PteroNode['status'], { label: string; class: string; dot: string }> = {
  online: { label: 'Online', class: 'bg-success/15 text-success border-success/30', dot: 'bg-success' },
  offline: { label: 'Offline', class: 'bg-destructive/15 text-destructive border-destructive/30', dot: 'bg-destructive' },
  maintenance: { label: 'Konserwacja', class: 'bg-warning/15 text-warning border-warning/30', dot: 'bg-warning' },
};

export default function NodesPage() {
  const [nodes, setNodes] = useState<PteroNode[]>([]);
  const [locations, setLocations] = useState<PteroLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<PteroNode | null>(null);
  const [form, setForm] = useState({ name: '', locationId: '', fqdn: '', ram: 16384, disk: 51200 });

  useEffect(() => {
    Promise.all([getNodes(), getLocations()]).then(([n, l]) => {
      setNodes(n);
      setLocations(l);
      setLoading(false);
    });
  }, []);

  function openCreate() {
    setEditing(null);
    setForm({ name: '', locationId: '', fqdn: '', ram: 16384, disk: 51200 });
    setDialogOpen(true);
  }

  function openEdit(n: PteroNode) {
    setEditing(n);
    setForm({ name: n.name, locationId: '', fqdn: n.name.toLowerCase().replace('-', '.'), ram: n.ramTotal, disk: n.diskTotal });
    setDialogOpen(true);
  }

  function save() {
    if (!form.name || !form.fqdn) {
      toast.error('Wypełnij nazwę i adres FQDN.');
      return;
    }
    toast.success(editing ? 'Węzeł zaktualizowany.' : 'Węzeł dodany.');
    setDialogOpen(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Węzły</h1>
          <p className="text-sm text-muted-foreground mt-1">Zarządzanie węzłami infrastruktury</p>
        </div>
        <Button onClick={openCreate} className="gradient-primary text-white">
          <Plus className="mr-2 h-4 w-4" /> Dodaj węzeł
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {nodes.map((node) => {
            const st = statusMap[node.status];
            return (
              <Card key={node.id} className="glass p-5 hover:glow-sm transition-all">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="h-11 w-11 rounded-xl bg-primary/10 flex items-center justify-center">
                      <Network className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{node.name}</h3>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {node.location}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className={st.class}>
                    <span className={cn('h-1.5 w-1.5 rounded-full mr-1.5', st.dot)} />
                    {st.label}
                  </Badge>
                </div>

                <div className="space-y-3 mb-4">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5 text-muted-foreground"><Cpu className="h-3.5 w-3.5" /> CPU</span>
                      <span>{node.cpuUsed} / {node.cpuTotal}%</span>
                    </div>
                    <Progress value={(node.cpuUsed / node.cpuTotal) * 100} className="h-1.5" />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5 text-muted-foreground"><MemoryStick className="h-3.5 w-3.5" /> RAM</span>
                      <span>{(node.ramUsed / 1024).toFixed(1)} / {(node.ramTotal / 1024).toFixed(0)} GB</span>
                    </div>
                    <Progress value={(node.ramUsed / node.ramTotal) * 100} className="h-1.5" />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5 text-muted-foreground"><HardDrive className="h-3.5 w-3.5" /> Dysk</span>
                      <span>{(node.diskUsed / 1024).toFixed(1)} / {(node.diskTotal / 1024).toFixed(0)} GB</span>
                    </div>
                    <Progress value={(node.diskUsed / node.diskTotal) * 100} className="h-1.5" />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="rounded-lg bg-white/5 p-2">
                    <Server className="h-4 w-4 text-primary mx-auto mb-1" />
                    <p className="text-muted-foreground">Serwery</p>
                    <p className="font-semibold">{node.servers}</p>
                  </div>
                  <div className="rounded-lg bg-white/5 p-2">
                    <Network className="h-4 w-4 text-primary mx-auto mb-1" />
                    <p className="text-muted-foreground">Alokacje</p>
                    <p className="font-semibold">{node.allocationsUsed}/{node.allocations}</p>
                  </div>
                  <div className="rounded-lg bg-white/5 p-2">
                    <MapPin className="h-4 w-4 text-primary mx-auto mb-1" />
                    <p className="text-muted-foreground">Lokalizacja</p>
                    <p className="font-semibold">{node.location}</p>
                  </div>
                </div>

                <div className="mt-4 flex justify-end">
                  <Button size="sm" variant="outline" onClick={() => openEdit(node)}>
                    <Pencil className="h-3.5 w-3.5 mr-1" /> Edytuj
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="glass-strong">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edytuj węzeł' : 'Nowy węzeł'}</DialogTitle>
            <DialogDescription>
              {editing ? 'Zaktualizuj konfigurację węzła.' : 'Dodaj nowy węzeł do infrastruktury.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label>Nazwa węzła</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Warszawa-03" className="bg-background/50" />
            </div>
            <div className="space-y-2">
              <Label>Lokalizacja</Label>
              <Select value={form.locationId} onValueChange={(v) => setForm({ ...form, locationId: v })}>
                <SelectTrigger className="bg-background/50"><SelectValue placeholder="Wybierz lokalizację" /></SelectTrigger>
                <SelectContent>
                  {locations.map((l) => (
                    <SelectItem key={l.id} value={l.id}>{l.name} ({l.short})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Adres FQDN</Label>
              <Input value={form.fqdn} onChange={(e) => setForm({ ...form, fqdn: e.target.value })} placeholder="node.zenixhost.pl" className="bg-background/50" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>RAM (MB)</Label>
                <Input type="number" value={form.ram} onChange={(e) => setForm({ ...form, ram: +e.target.value })} className="bg-background/50" />
              </div>
              <div className="space-y-2">
                <Label>Dysk (MB)</Label>
                <Input type="number" value={form.disk} onChange={(e) => setForm({ ...form, disk: +e.target.value })} className="bg-background/50" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Anuluj</Button>
            <Button onClick={save} className="gradient-primary text-white">{editing ? 'Zapisz' : 'Dodaj'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
