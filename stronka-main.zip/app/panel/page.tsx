'use client';

import { useEffect, useState } from 'react';
import {
  Server,
  Activity,
  Users,
  Cpu,
  MemoryStick,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  Network,
  Clock,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  getServers,
  getUsers,
  getNodes,
  getActivity,
  generateCpuData,
  generateRamData,
  generateDiskData,
  generateServerActivityData,
} from '@/lib/pterodactyl';
import type { PteroServer, PteroUser, PteroNode, ActivityLog } from '@/lib/types';
import { cn } from '@/lib/utils';

const chartConfig = {
  cpu: { label: 'CPU', color: '#8B5CF6' },
  ram: { label: 'RAM', color: '#A78BFA' },
  disk: { label: 'Dysk', color: '#22D3EE' },
  aktywnosc: { label: 'Aktywność', color: '#8B5CF6' },
};

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: any;
  label: string;
  value: string;
  sub?: string;
  accent?: string;
}) {
  return (
    <Card className="glass p-5 hover:glow-sm transition-all duration-300">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
        </div>
        <div
          className="h-11 w-11 rounded-xl flex items-center justify-center"
          style={{ background: accent || 'rgba(139,92,246,0.15)' }}
        >
          <Icon className="h-5 w-5 text-primary" />
        </div>
      </div>
    </Card>
  );
}

export default function DashboardPage() {
  const [servers, setServers] = useState<PteroServer[]>([]);
  const [users, setUsers] = useState<PteroUser[]>([]);
  const [nodes, setNodes] = useState<PteroNode[]>([]);
  const [activity, setActivity] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  const [cpuData] = useState(generateCpuData());
  const [ramData] = useState(generateRamData());
  const [diskData] = useState(generateDiskData());
  const [serverActivityData] = useState(generateServerActivityData());

  useEffect(() => {
    Promise.all([getServers(), getUsers(), getNodes(), getActivity()]).then(
      ([s, u, n, a]) => {
        setServers(s);
        setUsers(u);
        setNodes(n);
        setActivity(a);
        setLoading(false);
      }
    );
  }, []);

  const activeServers = servers.filter((s) => s.status === 'running').length;
  const totalRamUsed = servers.reduce((sum, s) => sum + s.ram, 0);
  const totalRamLimit = servers.reduce((sum, s) => sum + s.ramLimit, 0);
  const totalDiskUsed = servers.reduce((sum, s) => sum + s.disk, 0);
  const totalDiskLimit = servers.reduce((sum, s) => sum + s.diskLimit, 0);
  const avgCpu = servers.length
    ? Math.round(servers.reduce((sum, s) => sum + s.cpu, 0) / servers.length)
    : 0;
  const pteroStatus = nodes.some((n) => n.status === 'online') ? 'Połączony' : 'Offline';
  const nodeStatus = nodes.length > 0 ? 'Online' : 'Offline';

  const activityIcon: Record<string, any> = {
    server: Server,
    user: Users,
    node: Network,
    system: AlertTriangle,
    security: CheckCircle2,
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Pulpit</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Przegląd infrastruktury ZenixHost
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Server} label="Serwery" value={String(servers.length)} sub={`${activeServers} aktywnych`} />
        <StatCard icon={Activity} label="Aktywne serwery" value={String(activeServers)} sub="uruchomione" accent="rgba(142,71,45,0.15)" />
        <StatCard icon={Users} label="Użytkownicy" value={String(users.length)} sub="zarejestrowani" accent="rgba(34,211,238,0.15)" />
        <StatCard icon={Cpu} label="Średnie CPU" value={`${avgCpu}%`} sub="wszystkie serwery" accent="rgba(139,92,246,0.15)" />
      </div>

      {/* Status row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="glass p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Status Pterodactyl</p>
              <p className="text-lg font-semibold mt-1 flex items-center gap-2">
                <span className={cn('h-2.5 w-2.5 rounded-full', pteroStatus === 'Połączony' ? 'bg-success animate-pulse' : 'bg-destructive')} />
                {pteroStatus}
              </p>
            </div>
            <CheckCircle2 className="h-8 w-8 text-success/60" />
          </div>
        </Card>
        <Card className="glass p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Status węzłów</p>
              <p className="text-lg font-semibold mt-1 flex items-center gap-2">
                <span className={cn('h-2.5 w-2.5 rounded-full', nodeStatus === 'Online' ? 'bg-success animate-pulse' : 'bg-destructive')} />
                {nodeStatus}
              </p>
            </div>
            <Network className="h-8 w-8 text-primary/60" />
          </div>
        </Card>
        <Card className="glass p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Zużycie RAM</p>
              <p className="text-lg font-semibold mt-1">{Math.round((totalRamUsed / Math.max(totalRamLimit, 1)) * 100)}%</p>
              <Progress value={(totalRamUsed / Math.max(totalRamLimit, 1)) * 100} className="h-1.5 mt-2" />
            </div>
            <MemoryStick className="h-8 w-8 text-primary/60" />
          </div>
        </Card>
        <Card className="glass p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Zużycie dysku</p>
              <p className="text-lg font-semibold mt-1">{Math.round((totalDiskUsed / Math.max(totalDiskLimit, 1)) * 100)}%</p>
              <Progress value={(totalDiskUsed / Math.max(totalDiskLimit, 1)) * 100} className="h-1.5 mt-2" />
            </div>
            <HardDrive className="h-8 w-8 text-primary/60" />
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="glass p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Cpu className="h-4 w-4 text-primary" /> Zużycie CPU (24h)
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={cpuData}>
              <defs>
                <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="time" stroke="#6b7280" fontSize={11} tickLine={false} />
              <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
              <Tooltip contentStyle={{ background: 'hsl(222 40% 10%)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: 8 }} />
              <Area type="monotone" dataKey="cpu" stroke="#8B5CF6" strokeWidth={2} fill="url(#cpuGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <MemoryStick className="h-4 w-4 text-primary" /> Zużycie RAM (24h)
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={ramData}>
              <defs>
                <linearGradient id="ramGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#A78BFA" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#A78BFA" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="time" stroke="#6b7280" fontSize={11} tickLine={false} />
              <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
              <Tooltip contentStyle={{ background: 'hsl(222 40% 10%)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: 8 }} />
              <Area type="monotone" dataKey="ram" stroke="#A78BFA" strokeWidth={2} fill="url(#ramGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <HardDrive className="h-4 w-4 text-primary" /> Zużycie dysku (24h)
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={diskData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="time" stroke="#6b7280" fontSize={11} tickLine={false} />
              <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
              <Tooltip contentStyle={{ background: 'hsl(222 40% 10%)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: 8 }} />
              <Line type="monotone" dataKey="disk" stroke="#22D3EE" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" /> Aktywność serwerów
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={serverActivityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="day" stroke="#6b7280" fontSize={11} tickLine={false} />
              <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
              <Tooltip contentStyle={{ background: 'hsl(222 40% 10%)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: 8 }} />
              <Bar dataKey="aktywnosc" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Activity */}
      <Card className="glass p-5">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" /> Ostatnie działania
        </h3>
        <div className="space-y-1">
          {activity.map((a) => {
            const Icon = activityIcon[a.type] || Activity;
            return (
              <div key={a.id} className="flex items-center gap-3 rounded-lg p-3 hover:bg-white/5 transition-colors">
                <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <span className="font-medium">{a.user}</span>{' '}
                    <span className="text-muted-foreground">{a.action}</span>{' '}
                    <span className="font-medium">{a.target}</span>
                  </p>
                </div>
                <span className="text-xs text-muted-foreground shrink-0">{a.timestamp}</span>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
