'use client';

import { useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  Play,
  Square,
  RotateCw,
  Skull,
  RefreshCw,
  Download,
  Trash2,
  Ban,
  Copy,
  Terminal,
  Folder,
  File as FileIcon,
  FolderPlus,
  FilePlus,
  Upload,
  HardDrive,
  Network,
  Settings,
  Activity,
  Cpu,
  MemoryStick,
  Database,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  Clock,
  ChevronRight,
} from 'lucide-react';
import { getServer, getBackups, getFiles, powerAction } from '@/lib/pterodactyl';
import type { PteroServer, Backup, FileEntry, ConsoleLine, ServerStatus } from '@/lib/types';
import { cn } from '@/lib/utils';

const statusMap: Record<ServerStatus, { label: string; class: string; dot: string }> = {
  running: { label: 'Uruchomiony', class: 'bg-success/15 text-success border-success/30', dot: 'bg-success' },
  starting: { label: 'Uruchamianie', class: 'bg-warning/15 text-warning border-warning/30', dot: 'bg-warning' },
  stopping: { label: 'Zatrzymywanie', class: 'bg-warning/15 text-warning border-warning/30', dot: 'bg-warning' },
  stopped: { label: 'Zatrzymany', class: 'bg-muted text-muted-foreground border-border', dot: 'bg-muted-foreground' },
  crashed: { label: 'Awaria', class: 'bg-destructive/15 text-destructive border-destructive/30', dot: 'bg-destructive' },
  installing: { label: 'Instalacja', class: 'bg-info/15 text-info border-info/30', dot: 'bg-info' },
  suspended: { label: 'Zawieszony', class: 'bg-destructive/15 text-destructive border-destructive/30', dot: 'bg-destructive' },
};

const initialLogs: ConsoleLine[] = [
  { id: '1', text: '[12:00:01] [Server thread/INFO]: Starting minecraft server version 1.20.4', type: 'log', timestamp: '12:00:01' },
  { id: '2', text: '[12:00:03] [Server thread/INFO]: Preparing level "world"', type: 'log', timestamp: '12:00:03' },
  { id: '3', text: '[12:00:05] [Server thread/INFO]: Loaded 748 recipes', type: 'success', timestamp: '12:00:05' },
  { id: '4', text: '[12:00:06] [Server thread/INFO]: Done (3.452s)! For help, type "help"', type: 'success', timestamp: '12:00:06' },
  { id: '5', text: '[12:01:20] [Server thread/WARN]: Can\'t keep up! Is the server overloaded?', type: 'warn', timestamp: '12:01:20' },
];

const lineColor: Record<ConsoleLine['type'], string> = {
  log: 'text-foreground/80',
  command: 'text-primary',
  error: 'text-destructive',
  success: 'text-success',
  warn: 'text-warning',
};

export default function ServerDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;
  const [server, setServer] = useState<PteroServer | null>(null);
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState<ConsoleLine[]>(initialLogs);
  const [command, setCommand] = useState('');
  const [backups, setBackups] = useState<Backup[]>([]);
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [currentPath, setCurrentPath] = useState('/');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const consoleEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    Promise.all([getServer(id), getBackups(id), getFiles(id)]).then(([s, b, f]) => {
      setServer(s);
      setBackups(b);
      setFiles(f);
      setLoading(false);
    });
  }, [id]);

  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  async function handlePower(action: 'start' | 'stop' | 'restart' | 'kill') {
    if (!server) return;
    setActionLoading(action);
    await powerAction(server.identifier, action);
    const labels: Record<string, string> = {
      start: 'uruchomiony',
      stop: 'zatrzymany',
      restart: 'restartowany',
      kill: 'zabity',
    };
    toast.success(`Serwer został ${labels[action]}.`);
    setActionLoading(null);
  }

  function sendCommand() {
    if (!command.trim()) return;
    const newLine: ConsoleLine = {
      id: String(Date.now()),
      text: `> ${command}`,
      type: 'command',
      timestamp: new Date().toLocaleTimeString('pl-PL'),
    };
    setLogs((prev) => [...prev, newLine]);
    setCommand('');
    // Simulate response
    setTimeout(() => {
      const responses = [
        'Wykonano pomyślnie.',
        'Nie znaleziono gracza.',
        'Komenda wymaga uprawnień operatora.',
        'Zapisano świat.',
      ];
      const resp: ConsoleLine = {
        id: String(Date.now() + 1),
        text: `[${new Date().toLocaleTimeString('pl-PL')}] [Server thread/INFO]: ${responses[Math.floor(Math.random() * responses.length)]}`,
        type: 'log',
        timestamp: new Date().toLocaleTimeString('pl-PL'),
      };
      setLogs((prev) => [...prev, resp]);
    }, 500);
  }

  function copyLogs() {
    const text = logs.map((l) => l.text).join('\n');
    navigator.clipboard.writeText(text);
    toast.success('Logi skopiowane do schowka.');
  }

  function clearConsole() {
    setLogs([]);
    toast.info('Konsola została wyczyszczona.');
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!server) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Nie znaleziono serwera.</p>
        <Button onClick={() => router.push('/panel/serwery')} className="mt-4">
          Wróć do listy
        </Button>
      </div>
    );
  }

  const st = statusMap[server.status];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => router.push('/panel/serwery')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">{server.name}</h1>
          <p className="text-sm text-muted-foreground">
            {server.owner} • {server.node} • ID: {server.identifier}
          </p>
        </div>
        <Badge variant="outline" className={st.class}>
          <span className={cn('h-1.5 w-1.5 rounded-full mr-1.5', st.dot)} />
          {st.label}
        </Badge>
      </div>

      {/* Power controls */}
      <Card className="glass p-4">
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={() => handlePower('start')}
            disabled={actionLoading === 'start' || server.status === 'running'}
            className="bg-success/90 hover:bg-success text-white"
          >
            {actionLoading === 'start' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            <span className="ml-2">Start</span>
          </Button>
          <Button
            onClick={() => handlePower('stop')}
            disabled={actionLoading === 'stop' || server.status === 'stopped'}
            variant="secondary"
          >
            {actionLoading === 'stop' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Square className="h-4 w-4" />}
            <span className="ml-2">Stop</span>
          </Button>
          <Button onClick={() => handlePower('restart')} disabled={actionLoading === 'restart'} variant="secondary">
            {actionLoading === 'restart' ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCw className="h-4 w-4" />}
            <span className="ml-2">Restart</span>
          </Button>
          <Button onClick={() => handlePower('kill')} disabled={actionLoading === 'kill'} variant="destructive">
            {actionLoading === 'kill' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Skull className="h-4 w-4" />}
            <span className="ml-2">Kill</span>
          </Button>
          <div className="flex-1" />
          <Button variant="outline" onClick={() => toast.info('Rozpoczęto reinstalację serwera.')}>
            <RefreshCw className="h-4 w-4 mr-2" /> Reinstalacja
          </Button>
          <Button variant="outline" onClick={() => toast.success('Utworzono backup.')}>
            <HardDrive className="h-4 w-4 mr-2" /> Backup
          </Button>
          <Button variant="outline" onClick={() => toast.warning('Serwer został zawieszony.')}>
            <Ban className="h-4 w-4 mr-2" /> Zawieś
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">
                <Trash2 className="h-4 w-4 mr-2" /> Usuń
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Usunąć serwer?</AlertDialogTitle>
                <AlertDialogDescription>
                  Ta operacja jest nieodwracalna. Wszystkie dane serwera „{server.name}” zostaną trwale usunięte.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Anuluj</AlertDialogCancel>
                <AlertDialogAction onClick={() => { toast.success('Serwer został usunięty.'); router.push('/panel/serwery'); }}>
                  Usuń trwale
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </Card>

      <Tabs defaultValue="console">
        <TabsList className="bg-card/50 border border-white/5 flex-wrap h-auto">
          <TabsTrigger value="console"><Terminal className="h-4 w-4 mr-2" />Konsola</TabsTrigger>
          <TabsTrigger value="files"><Folder className="h-4 w-4 mr-2" />Pliki</TabsTrigger>
          <TabsTrigger value="backups"><HardDrive className="h-4 w-4 mr-2" />Backupy</TabsTrigger>
          <TabsTrigger value="network"><Network className="h-4 w-4 mr-2" />Sieć</TabsTrigger>
          <TabsTrigger value="settings"><Settings className="h-4 w-4 mr-2" />Ustawienia</TabsTrigger>
          <TabsTrigger value="resources"><Cpu className="h-4 w-4 mr-2" />Zasoby</TabsTrigger>
          <TabsTrigger value="activity"><Activity className="h-4 w-4 mr-2" />Aktywność</TabsTrigger>
        </TabsList>

        {/* Console */}
        <TabsContent value="console">
          <Card className="glass p-0 overflow-hidden">
            <div className="flex items-center justify-between p-3 border-b border-white/5">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Terminal className="h-4 w-4 text-primary" /> Konsola na żywo
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" onClick={copyLogs}>
                  <Copy className="h-3.5 w-3.5 mr-1" /> Kopiuj
                </Button>
                <Button size="sm" variant="ghost" onClick={clearConsole}>
                  Wyczyść
                </Button>
              </div>
            </div>
            <div className="h-[400px] overflow-y-auto scrollbar-thin bg-black/40 p-4 font-mono text-sm space-y-1">
              {logs.map((line) => (
                <div key={line.id} className={cn('whitespace-pre-wrap break-all', lineColor[line.type])}>
                  {line.text}
                </div>
              ))}
              <div ref={consoleEndRef} />
            </div>
            <div className="flex gap-2 p-3 border-t border-white/5">
              <Input
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendCommand()}
                placeholder="Wpisz komendę i naciśnij Enter..."
                className="bg-background/50 font-mono"
              />
              <Button onClick={sendCommand} className="gradient-primary text-white">
                Wyślij
              </Button>
            </div>
          </Card>
        </TabsContent>

        {/* Files */}
        <TabsContent value="files">
          <Card className="glass p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-sm">
                <Folder className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">{currentPath}</span>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => toast.info('Utworzono nowy folder.')}>
                  <FolderPlus className="h-3.5 w-3.5 mr-1" /> Nowy folder
                </Button>
                <Button size="sm" variant="outline" onClick={() => toast.info('Utworzono nowy plik.')}>
                  <FilePlus className="h-3.5 w-3.5 mr-1" /> Nowy plik
                </Button>
                <Button size="sm" variant="outline" onClick={() => toast.info('Wybierz plik do przesłania.')}>
                  <Upload className="h-3.5 w-3.5 mr-1" /> Prześlij
                </Button>
              </div>
            </div>
            <div className="space-y-1">
              {files.map((file) => (
                <div
                  key={file.name}
                  className="flex items-center gap-3 rounded-lg p-3 hover:bg-white/5 transition-colors cursor-pointer group"
                  onClick={() => {
                    if (file.type === 'folder') {
                      setCurrentPath(`${currentPath === '/' ? '' : currentPath}/${file.name}`);
                      toast.info(`Otworzono folder: ${file.name}`);
                    } else if (file.editable) {
                      toast.info(`Otworzono edytor: ${file.name}`);
                    } else {
                      toast.info(`Pobrano: ${file.name}`);
                    }
                  }}
                >
                  {file.type === 'folder' ? (
                    <Folder className="h-5 w-5 text-primary shrink-0" />
                  ) : (
                    <FileIcon className="h-5 w-5 text-muted-foreground shrink-0" />
                  )}
                  <span className="flex-1 text-sm">{file.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {file.type === 'file' ? `${(file.size / 1024).toFixed(1)} KB` : '—'}
                  </span>
                  <span className="text-xs text-muted-foreground">{file.modified}</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Backups */}
        <TabsContent value="backups">
          <Card className="glass p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Backupy serwera</h3>
              <Button size="sm" className="gradient-primary text-white" onClick={() => toast.success('Utworzono nowy backup.')}>
                <HardDrive className="h-3.5 w-3.5 mr-1" /> Utwórz backup
              </Button>
            </div>
            <div className="space-y-2">
              {backups.map((b) => (
                <div key={b.id} className="flex items-center gap-3 rounded-lg p-3 bg-white/5">
                  <HardDrive className="h-5 w-5 text-primary shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{b.name}</p>
                    <p className="text-xs text-muted-foreground">{b.createdAt} • {(b.size / 1024).toFixed(1)} MB</p>
                  </div>
                  <Badge variant="outline" className={b.status === 'completed' ? 'bg-success/15 text-success border-success/30' : 'bg-warning/15 text-warning border-warning/30'}>
                    {b.status === 'completed' ? 'Ukończony' : 'W toku'}
                  </Badge>
                  <Button size="sm" variant="ghost" onClick={() => toast.info('Pobieranie backupu...')}>
                    <Download className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => toast.success('Przywrócono serwer z backupu.')}>
                    <RotateCw className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-destructive" onClick={() => toast.error('Backup usunięty.')}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Network */}
        <TabsContent value="network">
          <Card className="glass p-4">
            <h3 className="font-semibold mb-4">Ustawienia sieci</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between rounded-lg p-3 bg-white/5">
                <div>
                  <p className="text-sm font-medium">Główny port</p>
                  <p className="text-xs text-muted-foreground">Port serwera</p>
                </div>
                <Badge variant="outline" className="font-mono">:{server.port}</Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg p-3 bg-white/5">
                <div>
                  <p className="text-sm font-medium">Liczba portów</p>
                  <p className="text-xs text-muted-foreground">Alokacje dodatkowe</p>
                </div>
                <Badge variant="outline">{server.ports}</Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg p-3 bg-white/5">
                <div>
                  <p className="text-sm font-medium">Adres IP</p>
                  <p className="text-xs text-muted-foreground">Węzeł {server.node}</p>
                </div>
                <Badge variant="outline" className="font-mono">0.0.0.0</Badge>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Settings */}
        <TabsContent value="settings">
          <Card className="glass p-4 space-y-4">
            <h3 className="font-semibold">Ustawienia serwera</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Nazwa serwera</Label>
                <Input defaultValue={server.name} className="bg-background/50" />
              </div>
              <div className="space-y-2">
                <Label>Właściciel</Label>
                <Input defaultValue={server.owner} disabled className="bg-background/50" />
              </div>
              <div className="space-y-2">
                <Label>Egg</Label>
                <Input defaultValue={server.egg} disabled className="bg-background/50" />
              </div>
              <div className="space-y-2">
                <Label>Węzeł</Label>
                <Input defaultValue={server.node} disabled className="bg-background/50" />
              </div>
            </div>
            <Button className="gradient-primary text-white" onClick={() => toast.success('Zapisano ustawienia.')}>
              Zapisz zmiany
            </Button>
          </Card>
        </TabsContent>

        {/* Resources */}
        <TabsContent value="resources">
          <div className="grid gap-4 sm:grid-cols-3">
            <Card className="glass p-5">
              <div className="flex items-center gap-2 mb-3">
                <Cpu className="h-4 w-4 text-primary" />
                <h4 className="font-medium text-sm">CPU</h4>
              </div>
              <p className="text-2xl font-bold">{server.cpuLimit}%</p>
              <p className="text-xs text-muted-foreground mt-1">Limit procesora</p>
              <Progress value={(server.cpu / Math.max(server.cpuLimit, 1)) * 100} className="h-1.5 mt-3" />
            </Card>
            <Card className="glass p-5">
              <div className="flex items-center gap-2 mb-3">
                <MemoryStick className="h-4 w-4 text-primary" />
                <h4 className="font-medium text-sm">RAM</h4>
              </div>
              <p className="text-2xl font-bold">{(server.ramLimit / 1024).toFixed(1)} GB</p>
              <p className="text-xs text-muted-foreground mt-1">Limit pamięci</p>
              <Progress value={(server.ram / Math.max(server.ramLimit, 1)) * 100} className="h-1.5 mt-3" />
            </Card>
            <Card className="glass p-5">
              <div className="flex items-center gap-2 mb-3">
                <HardDrive className="h-4 w-4 text-primary" />
                <h4 className="font-medium text-sm">Dysk</h4>
              </div>
              <p className="text-2xl font-bold">{(server.diskLimit / 1024).toFixed(1)} GB</p>
              <p className="text-xs text-muted-foreground mt-1">Limit dysku</p>
              <Progress value={(server.disk / Math.max(server.diskLimit, 1)) * 100} className="h-1.5 mt-3" />
            </Card>
            <Card className="glass p-5">
              <div className="flex items-center gap-2 mb-3">
                <Database className="h-4 w-4 text-primary" />
                <h4 className="font-medium text-sm">Bazy danych</h4>
              </div>
              <p className="text-2xl font-bold">{server.databases}</p>
              <p className="text-xs text-muted-foreground mt-1">Przydzielone</p>
            </Card>
            <Card className="glass p-5">
              <div className="flex items-center gap-2 mb-3">
                <HardDrive className="h-4 w-4 text-primary" />
                <h4 className="font-medium text-sm">Backupy</h4>
              </div>
              <p className="text-2xl font-bold">{server.backups}</p>
              <p className="text-xs text-muted-foreground mt-1">Limit backupów</p>
            </Card>
            <Card className="glass p-5">
              <div className="flex items-center gap-2 mb-3">
                <Network className="h-4 w-4 text-primary" />
                <h4 className="font-medium text-sm">Porty</h4>
              </div>
              <p className="text-2xl font-bold">{server.ports}</p>
              <p className="text-xs text-muted-foreground mt-1">Alokacje</p>
            </Card>
          </div>
        </TabsContent>

        {/* Activity */}
        <TabsContent value="activity">
          <Card className="glass p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" /> Aktywność serwera
            </h3>
            <div className="space-y-2">
              {[
                { time: '14:32', text: 'Serwer uruchomiony', icon: Play },
                { time: '14:30', text: 'Zmiana ustawień server.properties', icon: Settings },
                { time: '13:15', text: 'Utworzono backup „Przed aktualizacją"', icon: HardDrive },
                { time: '12:48', text: 'Wykryto wysokie zużycie CPU', icon: Activity },
                { time: '10:00', text: 'Serwer zatrzymany przez administratora', icon: Square },
              ].map((a, i) => {
                const Icon = a.icon;
                return (
                  <div key={i} className="flex items-center gap-3 rounded-lg p-3 hover:bg-white/5">
                    <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <p className="text-sm flex-1">{a.text}</p>
                    <span className="text-xs text-muted-foreground">{a.time}</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
