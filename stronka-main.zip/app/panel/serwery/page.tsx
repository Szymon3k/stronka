'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Search,
  Plus,
  Server,
  Cpu,
  MemoryStick,
  HardDrive,
  ArrowUpDown,
  ExternalLink,
  Loader2,
} from 'lucide-react';
import { getServers } from '@/lib/pterodactyl';
import type { PteroServer, ServerStatus } from '@/lib/types';
import { cn } from '@/lib/utils';

const statusMap: Record<ServerStatus, { label: string; class: string; dot: string }> = {
  running: { label: 'Uruchomiony', class: 'bg-success/15 text-success border-success/30', dot: 'bg-success' },
  starting: { label: 'Uruchamianie', class: 'bg-warning/15 text-warning border-warning/30', dot: 'bg-warning' },
  stopping: { label: 'Zatrzymywanie', class: 'bg-warning/15 text-warning border-warning/30', dot: 'bg-warning' },
  stopped: { label: 'Zatrzymany', class: 'bg-muted text-muted-foreground border-border', dot: 'bg-muted-foreground' },
  crashed: { label: 'Awaria', class: 'bg-destructive/15 text-destructive border-destructive/30', dot: 'bg-destructive' },
  installing: { label: 'Instalacja', class: 'bg-info/15 text-info border-info/30', dot: 'bg-info' },
  suspended: { label: 'Zawieszony', class: 'bg-destructive/15 text-destructive border-destructive/30', dot: 'bg-destructive' },
};

export default function ServersPage() {
  const [servers, setServers] = useState<PteroServer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [nodeFilter, setNodeFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('name');

  useEffect(() => {
    getServers().then((s) => {
      setServers(s);
      setLoading(false);
    });
  }, []);

  const nodes = useMemo(() => Array.from(new Set(servers.map((s) => s.node))), [servers]);

  const filtered = useMemo(() => {
    let list = servers.filter((s) => {
      const matchSearch =
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.owner.toLowerCase().includes(search.toLowerCase()) ||
        s.identifier.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || s.status === statusFilter;
      const matchNode = nodeFilter === 'all' || s.node === nodeFilter;
      return matchSearch && matchStatus && matchNode;
    });
    list = [...list].sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'ram') return b.ramLimit - a.ramLimit;
      if (sortBy === 'cpu') return b.cpuLimit - a.cpuLimit;
      if (sortBy === 'disk') return b.diskLimit - a.diskLimit;
      if (sortBy === 'date') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      return 0;
    });
    return list;
  }, [servers, search, statusFilter, nodeFilter, sortBy]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Serwery</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Zarządzanie serwerami z Pterodactyl API
          </p>
        </div>
        <Button asChild className="gradient-primary text-white hover:opacity-90">
          <Link href="/panel/serwery/nowy">
            <Plus className="mr-2 h-4 w-4" />
            Utwórz serwer
          </Link>
        </Button>
      </div>

      {/* Filters */}
      <Card className="glass p-4">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Szukaj po nazwie, właścicielu lub ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-background/50"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px] bg-background/50">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Wszystkie statusy</SelectItem>
              <SelectItem value="running">Uruchomione</SelectItem>
              <SelectItem value="stopped">Zatrzymane</SelectItem>
              <SelectItem value="crashed">Awaria</SelectItem>
              <SelectItem value="suspended">Zawieszone</SelectItem>
            </SelectContent>
          </Select>
          <Select value={nodeFilter} onValueChange={setNodeFilter}>
            <SelectTrigger className="w-[160px] bg-background/50">
              <SelectValue placeholder="Węzeł" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Wszystkie węzły</SelectItem>
              {nodes.map((n) => (
                <SelectItem key={n} value={n}>{n}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px] bg-background/50">
              <ArrowUpDown className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Nazwa (A-Z)</SelectItem>
              <SelectItem value="ram">RAM (malejąco)</SelectItem>
              <SelectItem value="cpu">CPU (malejąco)</SelectItem>
              <SelectItem value="disk">Dysk (malejąco)</SelectItem>
              <SelectItem value="date">Data utworzenia</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filtered.length === 0 ? (
        <Card className="glass p-12 text-center">
          <Server className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Brak serwerów spełniających kryteria.</p>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((server) => {
            const st = statusMap[server.status];
            return (
              <Link key={server.id} href={`/panel/serwery/${server.identifier}`} className="block group">
                <Card className="glass p-5 h-full hover:glow transition-all duration-300 group-hover:border-primary/30">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                        <Server className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold truncate">{server.name}</h3>
                        <p className="text-xs text-muted-foreground truncate">{server.owner}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className={cn('shrink-0', st.class)}>
                      <span className={cn('h-1.5 w-1.5 rounded-full mr-1.5', st.dot)} />
                      {st.label}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center mb-4">
                    <div className="rounded-lg bg-white/5 p-2">
                      <Cpu className="h-4 w-4 text-primary mx-auto mb-1" />
                      <p className="text-xs text-muted-foreground">CPU</p>
                      <p className="text-sm font-semibold">{server.cpuLimit}%</p>
                    </div>
                    <div className="rounded-lg bg-white/5 p-2">
                      <MemoryStick className="h-4 w-4 text-primary mx-auto mb-1" />
                      <p className="text-xs text-muted-foreground">RAM</p>
                      <p className="text-sm font-semibold">{(server.ramLimit / 1024).toFixed(0)} GB</p>
                    </div>
                    <div className="rounded-lg bg-white/5 p-2">
                      <HardDrive className="h-4 w-4 text-primary mx-auto mb-1" />
                      <p className="text-xs text-muted-foreground">Dysk</p>
                      <p className="text-sm font-semibold">{(server.diskLimit / 1024).toFixed(0)} GB</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{server.node}</span>
                    <span className="flex items-center gap-1">
                      :{server.port}
                      <ExternalLink className="h-3 w-3" />
                    </span>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
