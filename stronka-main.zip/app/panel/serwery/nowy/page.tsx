'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft, Loader2, Server, Cpu, MemoryStick, HardDrive, Database, HardDriveDownload, Network } from 'lucide-react';
import { getEggs, getLocations, getUsers, getNodes, createServer } from '@/lib/pterodactyl';
import type { PteroEgg, PteroLocation, PteroUser, PteroNode } from '@/lib/types';

export default function CreateServerPage() {
  const router = useRouter();
  const [eggs, setEggs] = useState<PteroEgg[]>([]);
  const [locations, setLocations] = useState<PteroLocation[]>([]);
  const [users, setUsers] = useState<PteroUser[]>([]);
  const [nodes, setNodes] = useState<PteroNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [form, setForm] = useState({
    name: '',
    userId: '',
    eggId: '',
    nodeId: '',
    ram: 2048,
    cpu: 200,
    disk: 5120,
    databases: 1,
    backups: 1,
    ports: 1,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    Promise.all([getEggs(), getLocations(), getUsers(), getNodes()]).then(
      ([e, l, u, n]) => {
        setEggs(e);
        setLocations(l);
        setUsers(u);
        setNodes(n);
        setLoading(false);
      }
    );
  }, []);

  function validate() {
    const errs: Record<string, string> = {};
    if (!form.name || form.name.length < 3) errs.name = 'Nazwa musi mieć co najmniej 3 znaki.';
    if (!form.userId) errs.userId = 'Wybierz użytkownika.';
    if (!form.eggId) errs.eggId = 'Wybierz egg.';
    if (!form.nodeId) errs.nodeId = 'Wybierz węzeł.';
    if (form.ram < 512) errs.ram = 'RAM musi wynosić co najmniej 512 MB.';
    if (form.cpu < 50) errs.cpu = 'CPU musi wynosić co najmniej 50%.';
    if (form.disk < 1024) errs.disk = 'Dysk musi wynosić co najmniej 1024 MB.';
    if (form.databases < 0) errs.databases = 'Wartość nie może być ujemna.';
    if (form.backups < 0) errs.backups = 'Wartość nie może być ujemna.';
    if (form.ports < 1) errs.ports = 'Musi być co najmniej 1 port.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) {
      toast.error('Popraw błędy w formularzu.');
      return;
    }
    setSubmitting(true);
    const res = await createServer(form);
    setSubmitting(false);
    if (!res.success) {
      toast.error(res.error || 'Nie udało się utworzyć serwera.');
      return;
    }
    toast.success('Serwer został utworzony pomyślnie.');
    router.push('/panel/serwery');
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => router.push('/panel/serwery')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Nowy serwer</h1>
          <p className="text-sm text-muted-foreground mt-1">Utwórz serwer przez Pterodactyl Application API</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card className="glass p-6 space-y-6">
          {/* Basic */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Server className="h-4 w-4 text-primary" /> Podstawowe informacje
            </h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label>Nazwa serwera</Label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Mój serwer"
                  className="bg-background/50"
                />
                {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
              </div>
              <div className="space-y-2">
                <Label>Użytkownik</Label>
                <Select value={form.userId} onValueChange={(v) => setForm({ ...form, userId: v })}>
                  <SelectTrigger className="bg-background/50"><SelectValue placeholder="Wybierz użytkownika" /></SelectTrigger>
                  <SelectContent>
                    {users.map((u) => (
                      <SelectItem key={u.id} value={u.id}>{u.firstName} {u.lastName} ({u.email})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.userId && <p className="text-xs text-destructive">{errors.userId}</p>}
              </div>
              <div className="space-y-2">
                <Label>Egg</Label>
                <Select value={form.eggId} onValueChange={(v) => setForm({ ...form, eggId: v })}>
                  <SelectTrigger className="bg-background/50"><SelectValue placeholder="Wybierz egg" /></SelectTrigger>
                  <SelectContent>
                    {eggs.map((e) => (
                      <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.eggId && <p className="text-xs text-destructive">{errors.eggId}</p>}
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>Węzeł</Label>
                <Select value={form.nodeId} onValueChange={(v) => setForm({ ...form, nodeId: v })}>
                  <SelectTrigger className="bg-background/50"><SelectValue placeholder="Wybierz węzeł" /></SelectTrigger>
                  <SelectContent>
                    {nodes.map((n) => (
                      <SelectItem key={n.id} value={n.id}>{n.name} ({n.location})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.nodeId && <p className="text-xs text-destructive">{errors.nodeId}</p>}
              </div>
            </div>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Cpu className="h-4 w-4 text-primary" /> Zasoby
            </h3>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><MemoryStick className="h-3.5 w-3.5" /> RAM (MB)</Label>
                <Input type="number" value={form.ram} onChange={(e) => setForm({ ...form, ram: +e.target.value })} className="bg-background/50" />
                {errors.ram && <p className="text-xs text-destructive">{errors.ram}</p>}
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Cpu className="h-3.5 w-3.5" /> CPU (%)</Label>
                <Input type="number" value={form.cpu} onChange={(e) => setForm({ ...form, cpu: +e.target.value })} className="bg-background/50" />
                {errors.cpu && <p className="text-xs text-destructive">{errors.cpu}</p>}
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><HardDrive className="h-3.5 w-3.5" /> Dysk (MB)</Label>
                <Input type="number" value={form.disk} onChange={(e) => setForm({ ...form, disk: +e.target.value })} className="bg-background/50" />
                {errors.disk && <p className="text-xs text-destructive">{errors.disk}</p>}
              </div>
            </div>
          </div>

          {/* Feature limits */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Database className="h-4 w-4 text-primary" /> Limity funkcji
            </h3>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Database className="h-3.5 w-3.5" /> Bazy danych</Label>
                <Input type="number" min={0} value={form.databases} onChange={(e) => setForm({ ...form, databases: +e.target.value })} className="bg-background/50" />
                {errors.databases && <p className="text-xs text-destructive">{errors.databases}</p>}
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><HardDriveDownload className="h-3.5 w-3.5" /> Backupy</Label>
                <Input type="number" min={0} value={form.backups} onChange={(e) => setForm({ ...form, backups: +e.target.value })} className="bg-background/50" />
                {errors.backups && <p className="text-xs text-destructive">{errors.backups}</p>}
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Network className="h-3.5 w-3.5" /> Porty</Label>
                <Input type="number" min={1} value={form.ports} onChange={(e) => setForm({ ...form, ports: +e.target.value })} className="bg-background/50" />
                {errors.ports && <p className="text-xs text-destructive">{errors.ports}</p>}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => router.push('/panel/serwery')}>
              Anuluj
            </Button>
            <Button type="submit" disabled={submitting} className="gradient-primary text-white">
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Tworzenie...</> : 'Utwórz serwer'}
            </Button>
          </div>
        </Card>
      </form>
    </div>
  );
}
