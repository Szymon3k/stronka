import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Toaster } from '@/components/ui/sonner';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'ZenixHost — Panel Hostingowy',
  description: 'Nowoczesny panel hostingowy premium z integracją Pterodactyl.',
  icons: {
    icon: '/favicon.svg',
  },
  openGraph: {
    title: 'ZenixHost — Panel Hostingowy',
    description: 'Nowoczesny panel hostingowy premium z integracją Pterodactyl.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pl" className="dark">
      <body className={`${inter.className} antialiased`}>
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
