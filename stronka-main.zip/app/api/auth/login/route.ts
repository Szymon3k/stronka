import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const { username, password } = await req.json();
  // Demo: accept any non-empty credentials.
  // Integrate with your own auth system here.
  if (!username || !password) {
    return NextResponse.json({ error: 'Wprowadź nazwę użytkownika i hasło.' }, { status: 400 });
  }
  const res = NextResponse.json({ success: true, user: { username, role: 'admin' } });
  res.cookies.set('zenixhost_session', Buffer.from(JSON.stringify({ username, role: 'admin', ts: Date.now() })).toString('base64'), {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7,
    path: '/',
  });
  return res;
}
