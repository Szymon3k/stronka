import { NextRequest, NextResponse } from 'next/server';
import { createServer } from '@/lib/pterodactyl';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const result = await createServer(body);
  if (!result.success) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }
  return NextResponse.json(result);
}
