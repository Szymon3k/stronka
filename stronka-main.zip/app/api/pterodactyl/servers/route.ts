import { NextResponse } from 'next/server';
import { getServers } from '@/lib/pterodactyl';

export async function GET() {
  try {
    const servers = await getServers();
    return NextResponse.json({ servers });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
