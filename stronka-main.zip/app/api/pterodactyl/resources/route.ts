import { NextResponse } from 'next/server';
import { getEggs, getLocations } from '@/lib/pterodactyl';

export async function GET() {
  const [eggs, locations] = await Promise.all([getEggs(), getLocations()]);
  return NextResponse.json({ eggs, locations });
}
