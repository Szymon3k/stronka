import { NextRequest, NextResponse } from 'next/server';
import { powerAction } from '@/lib/pterodactyl';

export async function POST(req: NextRequest) {
  const { identifier, action } = await req.json();
  if (!identifier || !action) {
    return NextResponse.json({ error: 'Brak parametrów.' }, { status: 400 });
  }
  const result = await powerAction(identifier, action);
  return NextResponse.json(result);
}
