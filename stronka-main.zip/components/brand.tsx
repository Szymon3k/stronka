import { cn } from '@/lib/utils';

export function Logo({ className, size = 'md' }: { className?: string; size?: 'sm' | 'md' | 'lg' }) {
  const dims = size === 'sm' ? 'h-8 w-8' : size === 'lg' ? 'h-12 w-12' : 'h-10 w-10';
  const stroke = size === 'sm' ? 2.5 : size === 'lg' ? 4 : 3;
  return (
    <svg viewBox="0 0 64 64" className={cn(dims, className)} fill="none">
      <defs>
        <linearGradient id="zenix-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8B5CF6" />
          <stop offset="1" stopColor="#A78BFA" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="#0B1020" stroke="url(#zenix-grad)" strokeOpacity="0.3" />
      <path
        d="M18 46 L18 18 L46 46 L46 18"
        fill="none"
        stroke="url(#zenix-grad)"
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="32" cy="32" r="3.5" fill="#A78BFA" />
    </svg>
  );
}

export function BrandName({ className }: { className?: string }) {
  return (
    <span className={cn('font-bold tracking-tight', className)}>
      Zenix<span className="text-primary">Host</span>
    </span>
  );
}
